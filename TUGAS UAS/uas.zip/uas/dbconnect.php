<?php
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("sql311.hyperphp.com", "hp_27611921", "AdityaAnugrah10", "hp_27611921_uas");

if (!$conn) {
	echo "gagal konek database menn";
} else {
};
